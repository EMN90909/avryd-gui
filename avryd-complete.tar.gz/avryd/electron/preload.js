/**
 * AVRYD PRELOAD — exposes safe IPC bridge to renderer
 */
const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('avryd', {
  launch:       (cmd)  => ipcRenderer.invoke('system:launch', cmd),
  shell:        (cmd)  => ipcRenderer.invoke('system:shell', cmd),
  wallpapers:   ()     => ipcRenderer.invoke('wallpaper:list'),
  setWallpaper: (path) => ipcRenderer.invoke('wallpaper:set', path),
  version:      () => window.__AVRYD_VERSION__ || '1.0.0',
});
