/**
 * AVRYD ELECTRON MAIN PROCESS
 * Runs the Avryd shell as a full-screen Electron window.
 * In production this is launched by avryd-session after the compositor starts.
 */
const { app, BrowserWindow, ipcMain, shell, globalShortcut } = require('electron');
const path = require('path');
const { execSync, exec } = require('child_process');
const fs   = require('fs');

const DAEMON_URL    = 'http://localhost:7771';
const IS_DEV        = process.env.NODE_ENV === 'development';
const WALLPAPER_DIR = '/usr/share/avryd/wallpapers';
const VERSION_FILE  = '/usr/share/avryd/version';

let mainWindow;

function createWindow() {
  mainWindow = new BrowserWindow({
    fullscreen:     !IS_DEV,
    kiosk:          !IS_DEV,        // true kiosk mode in production
    frame:          false,
    transparent:    false,
    alwaysOnTop:    false,
    backgroundColor: '#4a9e95',
    webPreferences: {
      nodeIntegration:    false,
      contextIsolation:   true,
      preload:            path.join(__dirname, 'preload.js'),
    },
  });

  // Inject version from file
  const version = fs.existsSync(VERSION_FILE)
    ? fs.readFileSync(VERSION_FILE, 'utf8').trim()
    : '1.0.0';

  mainWindow.webContents.on('did-finish-load', () => {
    mainWindow.webContents.executeJavaScript(
      `window.__AVRYD_VERSION__ = "${version}";`
    );
  });

  if (IS_DEV) {
    mainWindow.loadURL('http://localhost:5173');
    mainWindow.webContents.openDevTools({ mode: 'detach' });
  } else {
    mainWindow.loadFile(path.join(__dirname, '../dist/index.html'));
  }

  // Crash recovery: if renderer crashes, restart after 2s
  mainWindow.webContents.on('render-process-gone', (_, details) => {
    console.error(`[Avryd] Renderer crashed: ${details.reason}`);
    setTimeout(() => {
      if (!mainWindow.isDestroyed()) mainWindow.reload();
    }, 2000);
  });
}

// ── IPC handlers (bridge to system) ──────────────────────────────────────────
ipcMain.handle('system:launch', async (_, cmd) => {
  exec(`DISPLAY=:0 ${cmd}`, (err) => { if (err) console.error(err); });
  return { ok: true };
});

ipcMain.handle('system:shell', async (_, cmd) => {
  try { return { output: execSync(cmd, { encoding: 'utf8' }) }; }
  catch (e) { return { error: e.message }; }
});

ipcMain.handle('wallpaper:list', async () => {
  try {
    const files = fs.readdirSync(WALLPAPER_DIR).filter(f => /\.(jpg|png|webp)$/i.test(f));
    return files.map(f => ({ name: f, path: path.join(WALLPAPER_DIR, f) }));
  } catch { return []; }
});

ipcMain.handle('wallpaper:set', async (_, filePath) => {
  exec(`feh --bg-scale "${filePath}"`, () => {});
  exec(`echo 'feh --bg-scale "${filePath}"' > ~/.fehbg`, () => {});
  return { ok: true };
});

// ── App lifecycle ─────────────────────────────────────────────────────────────
app.whenReady().then(() => {
  createWindow();

  // Emergency exit shortcut (only in dev or via secret combo)
  globalShortcut.register('Super+Shift+Q', () => {
    if (IS_DEV) app.quit();
  });
});

app.on('window-all-closed', () => {
  globalShortcut.unregisterAll();
  if (process.platform !== 'darwin') app.quit();
});

app.on('activate', () => {
  if (BrowserWindow.getAllWindows().length === 0) createWindow();
});
