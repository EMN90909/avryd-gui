/**
 * AVRYD DESKTOP ENVIRONMENT
 * Full GUI layer for Linux - React/Electron shell
 * Communicates with avryd-daemon via Unix socket / REST API
 * Update server: https://ui-avryd.onrender.com
 * Wallpapers: https://github.com/avryd/avryd-wallpapers
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Monitor, Battery, Wifi, Volume2, Search, Cpu, Layers, ShieldCheck,
  FolderOpen, Trash2, ChevronRight, Zap, Network, Settings, Globe,
  Terminal, Image, Music, Film, Archive, Clipboard, Lock, User,
  RefreshCw, Download, AlertCircle, CheckCircle, X, Minus, Square,
  ChevronUp, ChevronDown, Maximize2, LayoutGrid, Power, LogOut,
  Moon, Sun, HardDrive, Activity, Thermometer, Wind, Bell, BellOff,
  WifiOff, BatteryLow, BatteryCharging, Bluetooth, BluetoothOff,
  Volume1, VolumeX, Edit3, Folder, Home, Star, Clock, Package
} from 'lucide-react';

// ── STOCK WALLPAPER (base64 embedded, served from avryd-wallpapers.git) ──────
// In production this is loaded from /usr/share/avryd/wallpapers/stock.jpg
// or fetched from avryd-wallpapers.git via the update system.
// The WALLPAPER_SRC constant is injected at build time via wallpaper.js.
// For the artifact preview we use a teal gradient matching the uploaded image.
const STOCK_WALLPAPER_CSS = `url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='100%25' height='100%25'%3E%3Cdefs%3E%3CradialGradient id='a' cx='30%25' cy='25%25' r='60%25'%3E%3Cstop offset='0%25' stop-color='%2380cdc4'/%3E%3Cstop offset='40%25' stop-color='%2364b5ac'/%3E%3Cstop offset='100%25' stop-color='%234a9e95'/%3E%3C/radialGradient%3E%3CradialGradient id='b' cx='70%25' cy='70%25' r='50%25'%3E%3Cstop offset='0%25' stop-color='%2396d8d0' stop-opacity='0.7'/%3E%3Cstop offset='100%25' stop-color='%2356aaa1' stop-opacity='0'/%3E%3C/radialGradient%3E%3C/defs%3E%3Crect width='100%25' height='100%25' fill='url(%23a)'/%3E%3Crect width='100%25' height='100%25' fill='url(%23b)'/%3E%3C/svg%3E")`;

// ── UPDATE SERVER CONFIG ──────────────────────────────────────────────────────
const UPDATE_SERVER = 'https://ui-avryd.onrender.com';
const WALLPAPER_REPO = 'https://raw.githubusercontent.com/avryd/avryd-wallpapers/main';

// ── AVRYD DAEMON API (talks to local avryd-daemon on port 7771) ───────────────
const DAEMON_API = 'http://localhost:7771';

const daemonCall = async (endpoint, method = 'GET', body = null) => {
  try {
    const opts = { method, headers: { 'Content-Type': 'application/json' } };
    if (body) opts.body = JSON.stringify(body);
    const res = await fetch(`${DAEMON_API}${endpoint}`, opts);
    return await res.json();
  } catch {
    // Daemon not running — return mock data for UI preview
    return null;
  }
};

// ── APP REGISTRY ──────────────────────────────────────────────────────────────
const APPS = [
  { id: 'browser',    name: 'Browser',      icon: '🌐', cmd: 'xdg-open https://',   category: 'Internet' },
  { id: 'files',      name: 'Files',         icon: '📁', cmd: 'avryd-file-manager',  category: 'System' },
  { id: 'terminal',   name: 'Terminal',      icon: '💻', cmd: 'avryd-terminal',      category: 'System' },
  { id: 'settings',   name: 'Settings',      icon: '⚙️', cmd: 'avryd-settings',      category: 'System' },
  { id: 'editor',     name: 'Text Editor',   icon: '📝', cmd: 'avryd-editor',        category: 'Productivity' },
  { id: 'photos',     name: 'Photos',        icon: '🖼️', cmd: 'avryd-image-viewer',  category: 'Media' },
  { id: 'music',      name: 'Music',         icon: '🎵', cmd: 'avryd-audio-player',  category: 'Media' },
  { id: 'video',      name: 'Video',         icon: '🎬', cmd: 'avryd-video-player',  category: 'Media' },
  { id: 'archive',    name: 'Archive',       icon: '📦', cmd: 'avryd-archive',       category: 'Utilities' },
  { id: 'clipboard',  name: 'Clipboard',     icon: '📋', cmd: 'avryd-clipboard',     category: 'Utilities' },
  { id: 'screenshot', name: 'Screenshot',    icon: '📸', cmd: 'avryd-screenshot',    category: 'Utilities' },
  { id: 'monitor',    name: 'Task Manager',  icon: '📊', cmd: 'avryd-monitor',       category: 'System' },
  { id: 'mail',       name: 'Mail',          icon: '✉️', cmd: 'xdg-open mailto:',    category: 'Internet' },
  { id: 'calendar',   name: 'Calendar',      icon: '📅', cmd: 'avryd-calendar',      category: 'Productivity' },
  { id: 'lockscreen', name: 'Lock Screen',   icon: '🔒', cmd: 'avryd-lockscreen',    category: 'System' },
  { id: 'users',      name: 'Users',         icon: '👤', cmd: 'avryd-users',         category: 'System' },
];

const SIDEBAR_APPS = ['browser', 'files', 'terminal', 'settings'];

// ── UTILITY: launch app via daemon ────────────────────────────────────────────
const launchApp = (app) => daemonCall('/launch', 'POST', { cmd: app.cmd, id: app.id });

// ═════════════════════════════════════════════════════════════════════════════
//  MAIN COMPONENT
// ═════════════════════════════════════════════════════════════════════════════
export default function AvrydDesktop() {
  // Time & stats
  const [time, setTime]           = useState(new Date());
  const [cpuUsage, setCpu]        = useState(14);
  const [ramUsage, setRam]        = useState(43);
  const [batteryPct, setBattery]  = useState(74);
  const [charging, setCharging]   = useState(false);

  // Panels
  const [flyout, setFlyout]       = useState(null); // 'battery'|'network'|'sound'|'notifications'|'user'
  const [drawerOpen, setDrawer]   = useState(false);
  const [contextMenu, setCtx]     = useState(null); // {x,y,app}
  const [notifBadge, setNotifBadge] = useState(2);

  // Search
  const [query, setQuery]         = useState('');
  const [results, setResults]     = useState([]);
  const [searching, setSearching] = useState(false);

  // Settings state
  const [darkMode, setDark]       = useState(false);
  const [volume, setVolume]       = useState(72);
  const [muted, setMuted]         = useState(false);
  const [btEnabled, setBt]        = useState(true);
  const [wifiSSID, setSSID]       = useState('Avryd_5G');
  const [chargeLimit, setChargeLimit] = useState(80);
  const [batterySaver, setBatSaver]   = useState(false);

  // Update system
  const [updateAvail, setUpdateAvail]   = useState(false);
  const [updateVersion, setUpdateVer]   = useState('');
  const [updateStatus, setUpdateStatus] = useState(''); // 'checking'|'downloading'|'done'|'error'
  const [wallpapers, setWallpapers]     = useState([]);
  const [activeWall, setActiveWall]     = useState(null); // null = stock

  // Notifications
  const [notifications, setNotifs] = useState([
    { id: 1, title: 'Avryd', body: 'System ready. Welcome.', time: 'now', icon: '✅' },
    { id: 2, title: 'Updates', body: 'Check for updates from server.', time: '1m ago', icon: '⬆️' },
  ]);

  // ── Tick ────────────────────────────────────────────────────────────────────
  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    const s = setInterval(() => {
      setCpu(p  => Math.max(5,  Math.min(95, p  + (Math.random()*8  - 4))));
      setRam(p  => Math.max(30, Math.min(85, p  + (Math.random()*2  - 1))));
    }, 2000);
    return () => { clearInterval(t); clearInterval(s); };
  }, []);

  // ── Check for updates on mount ──────────────────────────────────────────────
  useEffect(() => {
    checkUpdates();
    fetchWallpapers();
  }, []);

  const checkUpdates = async () => {
    setUpdateStatus('checking');
    try {
      const res = await fetch(`${UPDATE_SERVER}/api/version`);
      if (res.ok) {
        const data = await res.json();
        if (data.version && data.version !== __AVRYD_VERSION__) {
          setUpdateAvail(true);
          setUpdateVer(data.version);
          setNotifs(prev => [...prev, {
            id: Date.now(), title: 'Update Available',
            body: `Avryd ${data.version} is ready to install.`, time: 'just now', icon: '⬆️'
          }]);
          setNotifBadge(n => n + 1);
        }
      }
    } catch { /* server not reachable */ }
    setUpdateStatus('');
  };

  const downloadUpdate = async () => {
    setUpdateStatus('downloading');
    try {
      const res = await fetch(`${UPDATE_SERVER}/api/update`, { method: 'POST' });
      if (res.ok) {
        setUpdateStatus('done');
        await daemonCall('/update/apply', 'POST');
        setUpdateAvail(false);
      } else { setUpdateStatus('error'); }
    } catch { setUpdateStatus('error'); }
  };

  const fetchWallpapers = async () => {
    try {
      const res = await fetch(`${WALLPAPER_REPO}/index.json`);
      if (res.ok) {
        const data = await res.json();
        setWallpapers(data.wallpapers || []);
      }
    } catch { /* repo not reachable, use stock */ }
  };

  // ── Search ──────────────────────────────────────────────────────────────────
  useEffect(() => {
    if (!query.trim()) { setResults([]); return; }
    const t = setTimeout(() => runSearch(query), 300);
    return () => clearTimeout(t);
  }, [query]);

  const runSearch = async (q) => {
    setSearching(true);
    // Search local apps first
    const appMatches = APPS.filter(a =>
      a.name.toLowerCase().includes(q.toLowerCase())
    ).map(a => ({ type: 'app', title: a.name, sub: a.category, app: a }));

    // Ask daemon for file results
    const fileData = await daemonCall(`/search?q=${encodeURIComponent(q)}`);
    const fileMatches = (fileData?.results || []).map(f => ({
      type: 'file', title: f.name, sub: f.path
    }));

    setResults([...appMatches, ...fileMatches].slice(0, 8));
    setSearching(false);
  };

  // ── Context menu ────────────────────────────────────────────────────────────
  const handleContextMenu = (e, app) => {
    e.preventDefault();
    setCtx({ x: e.clientX, y: e.clientY, app });
  };

  const closeAll = () => { setCtx(null); setFlyout(null); };

  // ── Wallpaper style ─────────────────────────────────────────────────────────
  const wallStyle = activeWall
    ? { backgroundImage: `url("${WALLPAPER_REPO}/${activeWall}")`, backgroundSize: 'cover', backgroundPosition: 'center' }
    : { backgroundImage: STOCK_WALLPAPER_CSS, backgroundSize: 'cover', backgroundPosition: 'center' };

  const isDark = darkMode;
  const glass  = isDark
    ? 'bg-black/30 border-white/10 text-white'
    : 'bg-white/40 border-white/60 text-slate-900';
  const glassFull = isDark
    ? 'bg-black/50 border-white/10 text-white backdrop-blur-3xl'
    : 'bg-white/70 border-white/60 text-slate-900 backdrop-blur-3xl';

  // ── Render ──────────────────────────────────────────────────────────────────
  return (
    <div
      className="relative w-full h-screen overflow-hidden font-sans select-none"
      style={wallStyle}
      onClick={closeAll}
    >
      {/* Dark mode overlay */}
      {isDark && <div className="absolute inset-0 bg-black/20 pointer-events-none z-0" />}

      {/* Grain texture */}
      <div className="fixed inset-0 pointer-events-none opacity-[0.025] z-[9998]"
        style={{ backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E")` }} />

      {/* ── BRANDING WATERMARK ─────────────────────────────────────────────── */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none select-none overflow-hidden z-0">
        <span className="text-[22vw] font-black tracking-tighter leading-none"
          style={{ color: isDark ? 'rgba(255,255,255,0.02)' : 'rgba(0,0,0,0.025)' }}>
          AVRYD
        </span>
      </div>

      {/* ═══════════════════════════════════════════════════════════════════════
          SYSTEM HUB — top right
      ═══════════════════════════════════════════════════════════════════════ */}
      <div className="fixed top-5 right-5 z-[1000] flex flex-col items-end gap-3" onClick={e => e.stopPropagation()}>

        {/* Hub bar */}
        <div className={`flex items-center gap-3 px-2 py-1.5 rounded-2xl border shadow-2xl backdrop-blur-3xl ${glass}`}>

          {/* CPU ring */}
          <div className="flex items-center gap-2 px-2 border-r border-black/10">
            <div className="relative w-8 h-8">
              <svg className="absolute inset-0 w-full h-full -rotate-90" viewBox="0 0 32 32">
                <circle cx="16" cy="16" r="13" fill="none" stroke="currentColor" strokeWidth="3" opacity="0.1"/>
                <circle cx="16" cy="16" r="13" fill="none" stroke="#2dd4bf" strokeWidth="3"
                  strokeDasharray="81.68" strokeDashoffset={81.68 - (81.68 * cpuUsage) / 100}
                  style={{ transition: 'stroke-dashoffset 1s ease' }}/>
              </svg>
              <span className="absolute inset-0 flex items-center justify-center text-[9px] font-black">{Math.round(cpuUsage)}%</span>
            </div>
            <div className="flex flex-col w-14">
              <div className="h-1.5 w-full rounded-full overflow-hidden" style={{ background: 'rgba(0,0,0,0.08)' }}>
                <div className="h-full rounded-full bg-teal-400" style={{ width: `${ramUsage}%`, transition: 'width 1s ease' }}/>
              </div>
              <span className="text-[8px] font-black opacity-40 uppercase mt-0.5">RAM {Math.round(ramUsage)}%</span>
            </div>
          </div>

          {/* Update badge */}
          {updateAvail && (
            <button onClick={() => setFlyout('update')}
              className="relative p-2 rounded-xl bg-teal-400 text-black animate-pulse">
              <Download size={16}/>
            </button>
          )}

          {/* Notification bell */}
          <button onClick={() => setFlyout(flyout === 'notifications' ? null : 'notifications')}
            className={`relative p-2 rounded-xl transition-all ${flyout === 'notifications' ? 'bg-teal-400 text-black' : 'hover:bg-white/40'}`}>
            <Bell size={17}/>
            {notifBadge > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-red-500 text-white text-[9px] font-black flex items-center justify-center">{notifBadge}</span>
            )}
          </button>

          {/* Wifi */}
          <button onClick={() => setFlyout(flyout === 'network' ? null : 'network')}
            className={`p-2 rounded-xl transition-all ${flyout === 'network' ? 'bg-teal-400 text-black' : 'hover:bg-white/40'}`}>
            <Wifi size={17}/>
          </button>

          {/* Battery */}
          <button onClick={() => setFlyout(flyout === 'battery' ? null : 'battery')}
            className={`p-2 rounded-xl transition-all ${flyout === 'battery' ? 'bg-teal-400 text-black' : 'hover:bg-white/40'}`}>
            {charging ? <BatteryCharging size={17}/> : batteryPct < 20 ? <BatteryLow size={17} className="text-red-500"/> : <Battery size={17}/>}
          </button>

          {/* Volume */}
          <button onClick={() => setFlyout(flyout === 'sound' ? null : 'sound')}
            className={`p-2 rounded-xl transition-all ${flyout === 'sound' ? 'bg-teal-400 text-black' : 'hover:bg-white/40'}`}>
            {muted ? <VolumeX size={17}/> : <Volume2 size={17}/>}
          </button>

          {/* User menu */}
          <button onClick={() => setFlyout(flyout === 'user' ? null : 'user')}
            className={`p-2 rounded-xl transition-all ${flyout === 'user' ? 'bg-teal-400 text-black' : 'hover:bg-white/40'}`}>
            <User size={17}/>
          </button>

          {/* Clock */}
          <div className="pl-3 pr-4 py-1 border-l border-black/10 flex flex-col items-end">
            <span className="text-sm font-black tracking-tighter leading-none">
              {time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })}
            </span>
            <span className="text-[9px] font-bold opacity-40 uppercase tracking-widest mt-0.5">
              {time.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' })}
            </span>
          </div>
        </div>

        {/* ── FLYOUTS ───────────────────────────────────────────────────────── */}

        {/* Battery flyout */}
        {flyout === 'battery' && (
          <FlyoutPanel title="Power Hub" icon={<Zap className="text-teal-500" size={18}/>} glass={glassFull}>
            <div className={`p-4 rounded-2xl mb-3 ${isDark ? 'bg-white/10' : 'bg-white/40'} border border-white/20`}>
              <div className="flex justify-between items-end mb-2">
                <span className="text-3xl font-black">{batteryPct}%</span>
                <span className="text-xs font-bold opacity-50">{charging ? 'Charging…' : '2h 45m left'}</span>
              </div>
              <div className="h-2 w-full rounded-full overflow-hidden" style={{ background: 'rgba(0,0,0,0.08)' }}>
                <div className="h-full bg-teal-400 transition-all duration-700" style={{ width: `${batteryPct}%` }}/>
              </div>
            </div>
            <label className="flex items-center justify-between p-3 rounded-xl hover:bg-white/20 transition cursor-pointer">
              <span className="text-sm font-bold">Battery Saver</span>
              <Toggle value={batterySaver} onChange={setBatSaver}/>
            </label>
            <div className="p-3">
              <div className="flex justify-between mb-2">
                <span className="text-sm font-bold">Charge Limit</span>
                <span className="text-sm font-black">{chargeLimit}%</span>
              </div>
              <input type="range" min={50} max={100} value={chargeLimit}
                onChange={e => { setChargeLimit(+e.target.value); daemonCall('/power/charge-limit', 'POST', { limit: +e.target.value }); }}
                className="w-full accent-teal-500"/>
            </div>
            <div className="flex gap-2 mt-2">
              <PillBtn onClick={() => daemonCall('/power/suspend', 'POST')} label="Suspend" icon={<Moon size={13}/>}/>
              <PillBtn onClick={() => daemonCall('/power/shutdown', 'POST')} label="Shutdown" icon={<Power size={13}/>} danger/>
            </div>
          </FlyoutPanel>
        )}

        {/* Network flyout */}
        {flyout === 'network' && (
          <FlyoutPanel title="Connectivity" icon={<Network className="text-teal-500" size={18}/>} glass={glassFull}>
            <div className="p-3 rounded-xl bg-teal-400 text-black flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <Wifi size={16}/><span className="text-sm font-bold">{wifiSSID}</span>
              </div>
              <ShieldCheck size={15}/>
            </div>
            <div className="text-[9px] uppercase font-black opacity-40 px-1 mt-3 mb-1">Available</div>
            {['Starlink_Alpha', 'Guest_Access', 'Neighbor_5G'].map(n => (
              <button key={n} onClick={() => { setSSID(n); daemonCall('/network/connect', 'POST', { ssid: n }); }}
                className="w-full flex items-center justify-between p-2.5 rounded-xl hover:bg-white/20 transition text-sm font-medium">
                <span>{n}</span><Wifi size={13} className="opacity-40"/>
              </button>
            ))}
            <div className="mt-3 flex items-center justify-between p-2.5 rounded-xl opacity-50">
              <div className="flex items-center gap-2 text-sm"><HardDrive size={14}/> Ethernet</div>
              <span className="text-xs">Disconnected</span>
            </div>
            <label className="flex items-center justify-between p-2.5 rounded-xl hover:bg-white/20 transition cursor-pointer mt-1">
              <div className="flex items-center gap-2 text-sm"><Bluetooth size={14}/> Bluetooth</div>
              <Toggle value={btEnabled} onChange={v => { setBt(v); daemonCall('/bluetooth/toggle', 'POST', { enabled: v }); }}/>
            </label>
          </FlyoutPanel>
        )}

        {/* Sound flyout */}
        {flyout === 'sound' && (
          <FlyoutPanel title="Audio" icon={<Volume2 className="text-teal-500" size={18}/>} glass={glassFull}>
            <div className="flex items-center gap-3 mb-3">
              <button onClick={() => { setMuted(!muted); daemonCall('/audio/mute', 'POST', { mute: !muted }); }}
                className="p-2 rounded-xl hover:bg-white/20 transition">
                {muted ? <VolumeX size={18}/> : <Volume2 size={18}/>}
              </button>
              <input type="range" min={0} max={100} value={muted ? 0 : volume}
                onChange={e => { setVolume(+e.target.value); setMuted(false); daemonCall('/audio/volume', 'POST', { volume: +e.target.value }); }}
                className="flex-1 accent-teal-500"/>
              <span className="text-sm font-black w-8 text-right">{muted ? 0 : volume}</span>
            </div>
            <div className="text-[9px] uppercase font-black opacity-40 px-1 mb-2">Output Device</div>
            {['Built-in Speakers', 'HDMI Audio', 'Bluetooth Headset'].map(d => (
              <button key={d} className="w-full text-left p-2.5 rounded-xl hover:bg-white/20 transition text-sm">{d}</button>
            ))}
          </FlyoutPanel>
        )}

        {/* Notifications flyout */}
        {flyout === 'notifications' && (
          <FlyoutPanel title="Notifications" icon={<Bell className="text-teal-500" size={18}/>} glass={glassFull}
            action={<button onClick={() => { setNotifs([]); setNotifBadge(0); }} className="text-xs font-bold opacity-50 hover:opacity-100">Clear all</button>}>
            {notifications.length === 0
              ? <p className="text-sm opacity-40 text-center py-4">No notifications</p>
              : notifications.map(n => (
                <div key={n.id} className={`p-3 rounded-xl mb-1 ${isDark ? 'bg-white/10' : 'bg-white/40'} flex gap-3`}>
                  <span className="text-xl">{n.icon}</span>
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-sm">{n.title}</div>
                    <div className="text-xs opacity-60 truncate">{n.body}</div>
                  </div>
                  <span className="text-[9px] opacity-40 whitespace-nowrap">{n.time}</span>
                </div>
              ))}
          </FlyoutPanel>
        )}

        {/* Update flyout */}
        {flyout === 'update' && (
          <FlyoutPanel title="System Update" icon={<Download className="text-teal-500" size={18}/>} glass={glassFull}>
            <div className={`p-4 rounded-2xl mb-3 ${isDark ? 'bg-white/10' : 'bg-white/40'} border border-white/20 text-center`}>
              <div className="text-2xl font-black mb-1">v{updateVersion}</div>
              <p className="text-xs opacity-60">New version available from ui-avryd.onrender.com</p>
            </div>
            {updateStatus === 'downloading'
              ? <div className="flex items-center gap-3 p-3"><div className="w-4 h-4 border-2 border-teal-400 border-t-transparent rounded-full animate-spin"/><span className="text-sm">Downloading…</span></div>
              : updateStatus === 'done'
              ? <div className="flex items-center gap-2 p-3 text-green-500"><CheckCircle size={16}/><span className="text-sm font-bold">Installed. Restart to apply.</span></div>
              : updateStatus === 'error'
              ? <div className="flex items-center gap-2 p-3 text-red-500"><AlertCircle size={16}/><span className="text-sm font-bold">Update failed.</span></div>
              : <button onClick={downloadUpdate} className="w-full p-3 rounded-xl bg-teal-400 text-black font-bold text-sm hover:bg-teal-300 transition flex items-center justify-center gap-2">
                  <Download size={15}/> Install Update
                </button>}
            <button onClick={() => daemonCall('/shell/restart', 'POST')}
              className="w-full mt-2 p-2.5 rounded-xl hover:bg-white/20 transition text-sm font-bold flex items-center justify-center gap-2 opacity-60">
              <RefreshCw size={14}/> Restart Shell
            </button>
          </FlyoutPanel>
        )}

        {/* User flyout */}
        {flyout === 'user' && (
          <FlyoutPanel title="Session" glass={glassFull}>
            <div className="flex items-center gap-3 p-3 mb-2">
              <div className="w-10 h-10 rounded-full bg-teal-400 flex items-center justify-center text-black font-black text-lg">A</div>
              <div>
                <div className="font-bold text-sm">avryd-user</div>
                <div className="text-xs opacity-50">Administrator</div>
              </div>
            </div>
            <label className="flex items-center justify-between p-3 rounded-xl hover:bg-white/20 cursor-pointer transition">
              <div className="flex items-center gap-2 text-sm">{isDark ? <Moon size={14}/> : <Sun size={14}/>} Dark Mode</div>
              <Toggle value={isDark} onChange={setDark}/>
            </label>
            <button onClick={() => setFlyout('wallpapers')}
              className="w-full flex items-center gap-2 p-3 rounded-xl hover:bg-white/20 transition text-sm font-medium">
              <Image size={14}/> Wallpapers
            </button>
            <button onClick={() => launchApp(APPS.find(a => a.id === 'settings'))}
              className="w-full flex items-center gap-2 p-3 rounded-xl hover:bg-white/20 transition text-sm font-medium">
              <Settings size={14}/> System Settings
            </button>
            <div className="h-px bg-black/10 my-1"/>
            <button onClick={() => daemonCall('/session/lock', 'POST')}
              className="w-full flex items-center gap-2 p-3 rounded-xl hover:bg-white/20 transition text-sm font-medium">
              <Lock size={14}/> Lock Screen
            </button>
            <button onClick={() => daemonCall('/session/logout', 'POST')}
              className="w-full flex items-center gap-2 p-3 rounded-xl hover:bg-red-500/20 hover:text-red-500 transition text-sm font-medium">
              <LogOut size={14}/> Log Out
            </button>
            <button onClick={() => daemonCall('/power/reboot', 'POST')}
              className="w-full flex items-center gap-2 p-3 rounded-xl hover:bg-red-500/20 hover:text-red-500 transition text-sm font-medium">
              <RefreshCw size={14}/> Restart
            </button>
            <button onClick={() => daemonCall('/power/shutdown', 'POST')}
              className="w-full flex items-center gap-2 p-3 rounded-xl hover:bg-red-500/20 hover:text-red-500 transition text-sm font-medium">
              <Power size={14}/> Shutdown
            </button>
          </FlyoutPanel>
        )}

        {/* Wallpapers flyout */}
        {flyout === 'wallpapers' && (
          <FlyoutPanel title="Wallpapers" icon={<Image className="text-teal-500" size={18}/>} glass={glassFull}
            action={<button onClick={fetchWallpapers} className="text-xs font-bold opacity-50 hover:opacity-100"><RefreshCw size={12}/></button>}>
            <button onClick={() => setActiveWall(null)}
              className={`w-full h-16 rounded-xl mb-2 overflow-hidden border-2 transition ${!activeWall ? 'border-teal-400' : 'border-transparent'}`}
              style={{ backgroundImage: STOCK_WALLPAPER_CSS, backgroundSize: 'cover' }}>
              <span className="sr-only">Stock wallpaper</span>
            </button>
            {wallpapers.length === 0
              ? <p className="text-xs opacity-40 text-center py-2">No extra wallpapers loaded.<br/>Check avryd-wallpapers.git</p>
              : <div className="grid grid-cols-2 gap-2">
                {wallpapers.map(w => (
                  <button key={w.file} onClick={() => setActiveWall(w.file)}
                    className={`h-16 rounded-xl overflow-hidden border-2 transition ${activeWall === w.file ? 'border-teal-400' : 'border-transparent'}`}
                    style={{ backgroundImage: `url("${WALLPAPER_REPO}/${w.thumb}")`, backgroundSize: 'cover' }}/>
                ))}
              </div>}
          </FlyoutPanel>
        )}
      </div>

      {/* ═══════════════════════════════════════════════════════════════════════
          SIDEBAR — left dock
      ═══════════════════════════════════════════════════════════════════════ */}
      <aside className={`fixed left-5 top-1/2 -translate-y-1/2 w-14 py-3 rounded-3xl border shadow-2xl backdrop-blur-3xl flex flex-col items-center gap-3 z-[500] ${glass}`}
        onClick={e => e.stopPropagation()}>

        {/* App drawer button */}
        <button onClick={() => setDrawer(true)}
          className="w-10 h-10 bg-teal-400 rounded-xl flex items-center justify-center text-black shadow-lg hover:scale-110 transition-transform">
          <LayoutGrid size={18} strokeWidth={2.5}/>
        </button>
        <div className="w-7 h-px bg-black/10"/>

        {/* Pinned apps */}
        {SIDEBAR_APPS.map(id => {
          const app = APPS.find(a => a.id === id);
          if (!app) return null;
          return (
            <button key={id}
              onClick={() => launchApp(app)}
              onContextMenu={e => handleContextMenu(e, app)}
              className="w-10 h-10 rounded-xl flex items-center justify-center hover:bg-white/40 hover:scale-110 transition-all group relative text-xl">
              {app.icon}
              <span className="absolute left-14 px-2 py-1 bg-black/80 text-white text-[10px] font-bold rounded-lg opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity whitespace-nowrap">
                {app.name}
              </span>
            </button>
          );
        })}
      </aside>

      {/* ═══════════════════════════════════════════════════════════════════════
          SEARCH CENTER
      ═══════════════════════════════════════════════════════════════════════ */}
      <div className="absolute top-[38%] left-1/2 -translate-x-1/2 -translate-y-1/2 w-full max-w-lg px-6 z-[400]"
        onClick={e => e.stopPropagation()}>
        <div className="relative group">
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 opacity-30 group-focus-within:opacity-70 transition-opacity text-teal-600" size={19}/>
          <input
            type="text"
            placeholder="Search apps, files, commands…"
            className={`w-full rounded-2xl py-4 px-14 shadow-2xl text-base font-medium focus:outline-none transition-all border backdrop-blur-2xl ${isDark ? 'bg-black/40 border-white/20 text-white placeholder:text-white/40 focus:ring-2 focus:ring-teal-400/40' : 'bg-white/80 border-white/60 placeholder:text-slate-400 focus:ring-4 focus:ring-teal-400/20'}`}
            value={query}
            onChange={e => setQuery(e.target.value)}
          />
          {searching && (
            <div className="absolute right-5 top-1/2 -translate-y-1/2">
              <div className="w-4 h-4 border-2 border-teal-400 border-t-transparent rounded-full animate-spin"/>
            </div>
          )}
        </div>

        {/* Results */}
        {results.length > 0 && (
          <div className={`mt-2 rounded-2xl border shadow-2xl overflow-hidden ${glassFull}`}>
            {results.map((r, i) => (
              <button key={i}
                onClick={() => { r.app && launchApp(r.app); setQuery(''); setResults([]); }}
                className={`w-full flex items-center gap-3 p-3 text-left hover:bg-teal-400/20 transition ${i > 0 ? 'border-t border-black/5' : ''}`}>
                <span className="text-lg w-7 text-center">{r.app?.icon || (r.type === 'file' ? '📄' : '🔍')}</span>
                <div className="flex-1 min-w-0">
                  <div className="font-bold text-sm truncate">{r.title}</div>
                  <div className="text-xs opacity-50 truncate">{r.sub}</div>
                </div>
                <ChevronRight size={13} className="opacity-30"/>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* ═══════════════════════════════════════════════════════════════════════
          APP DRAWER / LAUNCHER
      ═══════════════════════════════════════════════════════════════════════ */}
      {drawerOpen && (
        <div className="fixed inset-0 z-[2000] flex items-center justify-center"
          style={{ backdropFilter: 'blur(60px)', background: isDark ? 'rgba(0,0,0,0.6)' : 'rgba(255,255,255,0.2)' }}
          onClick={() => setDrawer(false)}>
          <div className={`w-full max-w-3xl mx-8 p-10 rounded-[3rem] border shadow-2xl ${glassFull}`}
            onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-4xl font-black tracking-tighter">Applications</h2>
              <button onClick={() => setDrawer(false)} className="p-2 rounded-xl hover:bg-white/20 transition"><X size={20}/></button>
            </div>
            {/* Group by category */}
            {['System', 'Internet', 'Productivity', 'Media', 'Utilities'].map(cat => {
              const catApps = APPS.filter(a => a.category === cat);
              if (!catApps.length) return null;
              return (
                <div key={cat} className="mb-6">
                  <div className="text-[10px] font-black uppercase opacity-30 tracking-widest mb-3">{cat}</div>
                  <div className="grid grid-cols-4 sm:grid-cols-6 gap-3">
                    {catApps.map(app => (
                      <button key={app.id}
                        onClick={() => { launchApp(app); setDrawer(false); }}
                        onContextMenu={e => handleContextMenu(e, app)}
                        className={`flex flex-col items-center gap-2 p-4 rounded-2xl border border-white/10 hover:bg-white/30 hover:shadow-lg transition-all group ${isDark ? 'bg-white/5' : 'bg-white/20'}`}>
                        <span className="text-3xl group-hover:scale-125 transition-transform duration-300">{app.icon}</span>
                        <span className="text-[11px] font-bold text-center leading-tight">{app.name}</span>
                      </button>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════════
          CONTEXT MENU
      ═══════════════════════════════════════════════════════════════════════ */}
      {contextMenu && (
        <div
          className={`fixed z-[3000] w-52 p-1.5 rounded-2xl border shadow-2xl backdrop-blur-2xl ${glassFull}`}
          style={{ top: contextMenu.y, left: contextMenu.x }}
          onClick={e => e.stopPropagation()}>
          <div className="px-3 py-2 text-[9px] font-black uppercase opacity-30 tracking-wider">
            {contextMenu.app?.name || 'Options'}
          </div>
          <CtxItem icon={<Package size={14}/>} label="Launch" onClick={() => { launchApp(contextMenu.app); closeAll(); }}/>
          <CtxItem icon={<ShieldCheck size={14}/>} label="Run as Root" onClick={() => { daemonCall('/launch', 'POST', { cmd: contextMenu.app?.cmd, sudo: true }); closeAll(); }}/>
          <CtxItem icon={<FolderOpen size={14}/>} label="Open File Location" onClick={() => { daemonCall('/files/open', 'POST', { path: `/usr/share/applications/${contextMenu.app?.id}.desktop` }); closeAll(); }}/>
          <div className="h-px bg-black/10 my-1"/>
          <CtxItem icon={<Edit3 size={14}/>} label="Pin to Sidebar" onClick={closeAll}/>
          <CtxItem icon={<Trash2 size={14}/>} label="Uninstall" onClick={closeAll} danger/>
        </div>
      )}

      {/* ═══════════════════════════════════════════════════════════════════════
          STATUS BAR — bottom center (taskbar)
      ═══════════════════════════════════════════════════════════════════════ */}
      <div className={`fixed bottom-5 left-1/2 -translate-x-1/2 z-[400] flex items-center gap-2 px-5 py-2 rounded-2xl border shadow-2xl backdrop-blur-3xl ${glass}`}>
        <Activity size={13} className="text-teal-400"/>
        <span className="text-[10px] font-black opacity-40 uppercase tracking-wider">Avryd OS</span>
        <div className="w-px h-4 bg-black/10"/>
        <span className="text-[10px] opacity-40">Quasar: Active</span>
        <div className="w-px h-4 bg-black/10"/>
        <span className="text-[10px] opacity-40">GPU: OK</span>
        <div className="w-px h-4 bg-black/10"/>
        <span className="text-[10px] opacity-40">IPC: Ready</span>
        {updateAvail && (
          <>
            <div className="w-px h-4 bg-black/10"/>
            <button onClick={() => setFlyout('update')} className="text-[10px] font-black text-teal-500 animate-pulse">
              ⬆ Update v{updateVersion}
            </button>
          </>
        )}
      </div>
    </div>
  );
}

// ── HELPER COMPONENTS ─────────────────────────────────────────────────────────

function FlyoutPanel({ title, icon, glass, children, action }) {
  return (
    <div className={`w-72 p-5 rounded-3xl border shadow-2xl ${glass}`} onClick={e => e.stopPropagation()}>
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          {icon}
          <h3 className="font-black text-base">{title}</h3>
        </div>
        {action}
      </div>
      {children}
    </div>
  );
}

function Toggle({ value, onChange }) {
  return (
    <button onClick={() => onChange(!value)}
      className={`relative w-10 h-5 rounded-full transition-colors ${value ? 'bg-teal-400' : 'bg-black/20'}`}>
      <span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white shadow transition-all ${value ? 'left-5' : 'left-0.5'}`}/>
    </button>
  );
}

function PillBtn({ onClick, label, icon, danger }) {
  return (
    <button onClick={onClick}
      className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl text-xs font-bold transition-all ${danger ? 'hover:bg-red-500/20 hover:text-red-500' : 'hover:bg-white/20'} opacity-70 hover:opacity-100`}>
      {icon}{label}
    </button>
  );
}

function CtxItem({ icon, label, onClick, danger }) {
  return (
    <button onClick={onClick}
      className={`w-full flex items-center gap-3 p-2.5 rounded-xl text-sm font-bold transition-all ${danger ? 'hover:bg-red-500 hover:text-white' : 'hover:bg-teal-400/30'}`}>
      {icon}{label}
    </button>
  );
}

// Version injected at build time by the update system
const __AVRYD_VERSION__ = typeof window !== 'undefined' && window.__AVRYD_VERSION__ ? window.__AVRYD_VERSION__ : '1.0.0';
